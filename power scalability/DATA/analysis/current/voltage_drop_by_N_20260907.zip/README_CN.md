# 按模块数量 N 汇总的压降图

本次为现有 Power 图的补充，未修改已发布的 main 2.3 或原组合热图。
对象为已接受的源端与模块端 DMM 主读数之差，单位 mV；不是高速瞬态压降。

## 文件

- [均值热图](module_drop_mean_by_N.png)：两种负载各一幅 N×模块矩阵。
- [N=1–4 四面板图](module_drop_N1_N4.png)：各组合点、模块均值及组合间样本 SD。
- module_drop_N1 至 module_drop_N4：四张可单独使用的图。
- 所有图提供 PNG（300 dpi）、PDF（矢量）和 SVG（可编辑文字）。
- module_drop_by_N_summary.csv：32行完整均值、SD、n、极值与对应组合。
- contributing_branch_readings.csv：64条来源分支，保留逐点 provenance。

## 统计口径

固定负载标签、N 和模块编号，对所有包含该模块的组合等权取平均；
没有把 M0–M3 或不同 N 混在一起平均。每个模块的 n 在 N=1/2/3/4
下分别为 1/3/3/1，这是组合数，不是独立重复次数。SD 使用 ddof=1；
N=1 和 N=4 没有可计算的 SD，留空而非写成零。N=2、ZERO、M2
的三个已记录读数恰好同为31 mV，所以其组合间SD为零，并不表示测量无不确定性。

| 负载 | N | 每模块 n | M0 / mV | M1 / mV | M2 / mV | M3 / mV |
|---|---:|---:|---:|---:|---:|---:|
| ZERO | 1 | 1 | 45.00 | 26.00 | 32.00 | 29.00 |
| ZERO | 2 | 3 | 44.33 ± 2.52 | 28.33 ± 2.08 | 31.00 ± 0.00 | 34.00 ± 3.61 |
| ZERO | 3 | 3 | 35.33 ± 0.58* | 27.33 ± 1.53 | 31.67 ± 2.08 | 29.00 ± 2.65 |
| ZERO | 4 | 1 | 34.00 | 29.00 | 31.00 | 26.00 |
| MAX | 1 | 1 | 50.00 | 31.00 | 34.00 | 32.00 |
| MAX | 2 | 3 | 37.33 ± 0.58 | 27.67 ± 2.08 | 34.33 ± 2.31 | 32.33 ± 1.53 |
| MAX | 3 | 3 | 36.67 ± 2.08 | 28.00 ± 1.73 | 33.33 ± 0.58 | 36.00 ± 6.93 |
| MAX | 4 | 1 | 36.00 | 28.00 | 33.00 | 31.00 |


星号：ZERO、N=3、M0 的三个值为35*、36、35 mV；35*采用单独复测
M0=3.241 V和用户确认未变的原SOURCE=3.276 V，属于跨记录估计。
旧接头故障的3.224 V及其52 mV差值仍在原始事件和报告中保留，不混入接受后的均值。

## 是否值得添加到论文

有价值，适合作为概览图。正文可使用均值热图，便于比较同一模块在不同N下的差异；
如果讨论组合间波动，使用四面板原始点+均值±SD图。原15组合热图应保留在附录，
避免平均数掩盖个别较高读数。一般无需把这两种概览和四张单图全部重复放进正文。

例如MAX、N=3、M3的三个值为32、32、44 mV，均值36.00±6.93 mV。
其中44 mV来自M1-M2-M3；仅凭这一读数不能判定接触故障或统计异常。
这些数据没有显示所有模块的压降随N一致增大的趋势；也不能把M0的下降
解释成扩展改善了供电。不同批次、组合与未完全定义的加载条件限制因果解释。
P-H2电压边界仍应基于逐点最低模块电压，平均压降不能代替最不利工况检查。

## Suggested captions

Mean heatmap: Mean source-to-module voltage differences for each physical
module at N=1–4, separated by recorded load label. Means include all combinations
containing that module (n=1,3,3,1, respectively); each exact condition has one
observation. The starred mean includes a separately retested M0 voltage with
the retained, user-confirmed source reading. All differences are derived
from sequential DMM main readings.

Point panels: Individual configuration voltage differences and their per-module
means at each N. Error bars are sample SD across combinations at N=2 and N=3,
not independent repeat uncertainty; SD is unavailable at N=1 and N=4.
The 44 mV loaded M3 reading and the starred M0 retest-derived point are retained.

复现：从 Final 目录运行 python -B "power scalability/script/Main/power_drop_by_count.py"。
绘图脚本和来源哈希记录在 figure_manifest.json。目标为本项目报告的补充图，
未声称满足某个期刊的投稿规范。
